function [RHSelem, gRHSelem, HESSelem, QHESSelem, RHESSelem, SHESSelem, DATAelem,...
    dlam_RHSelem, dlam_gRHSelem, dGamma_RHSelem, dGamma_gRHSelem] = ...
    getElemRHSandHESS_CosseratMedia_lin(intgID,dofhandler,gDOFhandler,params)
% Assemble elemental matrix for cosserat element (linear response)
% Orthotropic material properties
% Integration point based

nDIMs        = dofhandler.dim;
nDOFs        = dofhandler.dofs;
ngDOFs       = gDOFhandler.Ndofs;
pDIMs        = dofhandler.pdim;
NGamma       = params.NGamma;
Gammamat     = params.Gammamat;
Gammamatprev = params.Gammamatprev;

eNN      = dofhandler.eNNmat(intgID);
ipconnec = dofhandler.neighbormat(intgID,1:eNN);
Nmat     = dofhandler.Nmat(intgID,1:eNN);
dNmat    = dofhandler.dNmat(intgID,1:eNN*pDIMs);
w_k       = dofhandler.wkmat(intgID);

HESSelem   = zeros(eNN*nDOFs);
RHSelem    = zeros(eNN*nDOFs,1);

gRHSelem   = zeros(ngDOFs,1);
QHESSelem  = zeros(eNN*nDOFs,ngDOFs);
RHESSelem  = zeros(ngDOFs, eNN*nDOFs);
SHESSelem  = zeros(ngDOFs);

sctrVct  = nDOFs*(repmat(ipconnec,nDOFs,1)-1) + repmat((1:1:nDOFs)',1,eNN);
sctrVct  = sctrVct(:);
umat      = dofhandler.u(sctrVct);

coordsRmat   = zeros(nDIMs,eNN); % nodal coords
for m = 1:nDIMs
    coordsRmat(m,:) = dofhandler.coords(ipconnec,m);
end
coordsRmat = coordsRmat(:);
xcoordmat = coordsRmat(1:nDIMs:end);
ycoordmat = coordsRmat(2:nDIMs:end);

dlam_RHSelem = zeros(eNN*nDOFs,1);
dlam_gRHSelem = zeros(ngDOFs,1);

dGamma_RHSelem  = zeros(eNN*nDOFs, NGamma);
dGamma_gRHSelem = zeros(ngDOFs,    NGamma);

DATAelem   = zeros(1,2); % elemental data for plotting

E          = params.E;
A          = params.A;
I          = params.I;
LA         = params.Lx;
LB         = params.Ly;
pretension = params.pretension;
elemarea   = 0;

% Material properties for isotropic pretensed cosserat material
% lame1 = 1;
% lame2 = lame1;
% muc   = 0.5*lame2;
% l_c   = 10;
% Dmat = [lame1+2*lame2, lame1, 0, 0, 0, 0;...
%         lame1,    lame1+2*lame2, 0, 0, 0, 0;...
%         0, 0, lame2 + muc, lame2 - muc, 0, 0;...
%         0, 0, lame2 - muc, lame2 + muc, 0, 0;...
%         0, 0, 0, 0, 4*lame2*l_c^2, 0;...
%         0, 0, 0, 0, 0, 4*lame2*l_c^2];

% Material properties for orthotropic pretensed cosserat material
% (plane-stress)
EA = E * A/LA;
EB = E * A/LB;
kA = E * I/LA;
kB = E * I/LB;

alphaA = sqrt(pretension/E/I) * LA; 
alphaB = sqrt(pretension/E/I) * LB;

sA = alphaA * (alphaA *cosh(alphaA) - sinh(alphaA))/(2 - 2*cosh(alphaA) + alphaA*sinh(alphaA));
cA = (sinh(alphaA) - alphaA)/(alphaA*cosh(alphaA) - sinh(alphaA));
sppA = 2 * sA * (1 + cA) + pretension * LA/kA;

sB = alphaB * (alphaB *cosh(alphaB) - sinh(alphaB))/(2 - 2*cosh(alphaB) + alphaB*sinh(alphaB));
cB = (sinh(alphaB) - alphaB)/(alphaB*cosh(alphaB) - sinh(alphaB));
sppB = 2 * sB * (1 + cB) + pretension * LB/kB;

E11 = EA*LA/LB;
E22 = EB*LB/LA;

E12 = kA * sppA /LA/LB;
E21 = kB * sppB /LA/LB;

E13 = kA * sA * LA/LB;
E23 = kB * sB * LB/LA;

% Orthotrpic pretensioned fiber network
Dmat = [E11,   0,   0,   0,   0,   0;...
    0, E22,   0,   0,   0,   0;...
    0,   0, E12,   0,   0,   0;...
    0,   0,   0, E21,   0,   0;...
    0,   0,   0,   0, E13,   0;...
    0,   0,   0,   0,   0, E23];

p_k_mat  = Nmat(:); % eNN X 1
dp_k_mat = reshape(dNmat,pDIMs,eNN)'; % eNN * pdims

dxdxi      = zeros(2,2);
dxdxi(1,1) = sum(dp_k_mat(:,1) .* xcoordmat);
dxdxi(1,2) = sum(dp_k_mat(:,2) .* xcoordmat);
dxdxi(2,1) = sum(dp_k_mat(:,1) .* ycoordmat);
dxdxi(2,2) = sum(dp_k_mat(:,2) .* ycoordmat);
jac   = det(dxdxi);
dxidx = inv(dxdxi);

elemarea = elemarea + jac * w_k;

% Construct strain displacement mat
strainmat = zeros(6,1);
for I = 1:eNN
    dNIdxi = dp_k_mat(I,:);
    dNIdx = dNIdxi * dxidx;
    BI = [dNIdx(1),        0, 0;...
        0, dNIdx(2), 0;...
        0, dNIdx(1), -1;...
        dNIdx(2),        0,  1;...
        0,        0,  dNIdx(1);...
        0,        0,  dNIdx(2)];
    strainmat = strainmat + BI * umat(nDOFs*(I-1)+1:nDOFs*I);
end

stressmat =  Dmat * strainmat;
DATAelem(1) = stressmat(1);
DATAelem(2) = stressmat(2);

stress0mat = zeros(6,1);
stress0mat(1) = pretension/LB;
stress0mat(2) = pretension/LA;

duJ_stress0mat = zeros(6,3);

for I = 1:eNN
    dNIdxi = dp_k_mat(I,:);
    dNIdx = dNIdxi * dxidx;
    BI = [dNIdx(1),        0, 0;...
        0, dNIdx(2), 0;...
        0, dNIdx(1), -1;...
        dNIdx(2),        0,  1;...
        0,        0,  dNIdx(1);...
        0,        0,  dNIdx(2)];

    RHSelem(nDOFs*(I-1)+1:nDOFs*I) = RHSelem(nDOFs*(I-1)+1:nDOFs*I)...
        + BI' * stress0mat * jac * w_k;

    for J = 1:eNN
        dNJdxi = dp_k_mat(J,:);
        dNJdx = dNJdxi * dxidx;
        BJ = [dNJdx(1),        0, 0;...
            0, dNJdx(2), 0;...
            0, dNJdx(1), -1;...
            dNJdx(2),        0,  1;...
            0,        0,  dNJdx(1);...
            0,        0,  dNJdx(2)];

        duJ_stress0mat(3,3) = -pretension * p_k_mat(J)/LB;
        duJ_stress0mat(4,3) =  pretension * p_k_mat(J)/LA;

        HESSelem(nDOFs*(I-1)+1:nDOFs*I,nDOFs*(J-1)+1:nDOFs*J) ...
            = HESSelem(nDOFs*(I-1)+1:nDOFs*I,nDOFs*(J-1)+1:nDOFs*J)...
            + BI' * Dmat * BJ * jac * w_k + BI' * duJ_stress0mat * jac * w_k;
    end
end