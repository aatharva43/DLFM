function [coord_epicen,contractility,thCmax,Cmax,unitvecangle,contractility_theta] = ...
    getContractilityEpicenter(nodalForces,currpos,varargin)

epicenter_guess = mean(currpos);

% Solve using fmincon
% fmincon options
options   = optimoptions('fmincon','Display','notify','Algorithm','interior-point');

% options   = optimoptions(options,'SpecifyObjectiveGradient' ,true);
% options   = optimoptions(options,'StepTolerance',optimStepTol);
% options   = optimoptions(options,'TolFun',1E-6);
% options   = optimoptions(options,'OptimalityTolerance',optimOptTol);
% options   = optimoptions(options,'CheckGradients',true);

options   = optimoptions(options,'MaxIterations',200);
options   = optimoptions(options,'MaxFunctionEvaluations',1000);

% UB LB
ub = [];
lb = [];

InverseProbObj = @(epicenter)getEpicenterMinFunction(epicenter,nodalForces,currpos);

% Using fminunc
[coord_epicen,fval,exitflag,output] = fmincon(InverseProbObj, epicenter_guess,[],[],[],[],[],[],[],options);

% Calculate the contractility
contractility = abs(sum( sum(nodalForces.*(currpos - coord_epicen),2)./vecnorm(currpos - coord_epicen,2,2)));

% Calculate polarity and direction of maximum contractility
unitvecangle = linspace(0,2*pi,200)';
unitvec = [cos(unitvecangle),sin(unitvecangle)];
contractility_theta = zeros(size(unitvecangle));
nodalForces_aligned = nodalForces;
for i = 1:length(unitvecangle)
    nodalForces_aligned_mag = nodalForces(:,1)*unitvec(i,1) + nodalForces(:,2)*unitvec(i,2);
    nodalForces_aligned_mag = (nodalForces_aligned_mag - abs(nodalForces_aligned_mag))/2;
    nodalForces_aligned(:,1) = nodalForces_aligned_mag * unitvec(i,1);
    nodalForces_aligned(:,2) = nodalForces_aligned_mag * unitvec(i,2);
    contractility_theta(i) = sum( (sum(nodalForces_aligned.*(coord_epicen - currpos),2))./vecnorm(coord_epicen- currpos,2,2));
end

contractility_theta = abs(contractility_theta);

[Cmax,maxind] = max(abs(contractility_theta));
thCmax = unitvecangle(maxind);
