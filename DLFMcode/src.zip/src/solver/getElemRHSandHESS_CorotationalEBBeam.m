function [RHSelem, gRHSelem, HESSelem, QHESSelem, RHESSelem, SHESSelem, DATAelem,...
    dlam_RHSelem, dlam_gRHSelem, dGamma_RHSelem, dGamma_gRHSelem] = ...
    getElemRHSandHESS_CorotationalEBBeam(elemID,dofhandler,gDOFhandler,params)
% Assemble elemental matrix for beam

elemconnec   = dofhandler.connec(elemID,:);
eNN          = length(elemconnec);
nDOFs        = dofhandler.dofs;
ngDOFs       = gDOFhandler.Ndofs;
NGamma       = params.NGamma;
Gammamat     = params.Gammamat;
Gammamatprev = params.Gammamatprev;

%HESSelem   = zeros(eNN*nDOFs);
%RHSelem    = zeros(eNN*nDOFs,1);

gRHSelem   = zeros(ngDOFs,1);
QHESSelem  = zeros(eNN*nDOFs,ngDOFs);
RHESSelem  = zeros(ngDOFs, eNN*nDOFs);
SHESSelem  = zeros(ngDOFs);

dlam_RHSelem = zeros(eNN*nDOFs,1);
dlam_gRHSelem = zeros(ngDOFs,1);

dGamma_RHSelem  = zeros(eNN*nDOFs, NGamma);
dGamma_gRHSelem = zeros(ngDOFs,    NGamma);

DATAelem   = zeros(1,1); % elemental data for plotting

E         = params.E;
A         = params.A;
I         = params.I;
prestrain = params.prestrain;
uselinear = params.uselinear;

ndofs     = dofhandler.dofs;

node1 = dofhandler.connec(elemID,1);
node2 = dofhandler.connec(elemID,2);

% Get nodal coords and current displacements
X1 = dofhandler.coords(node1,1);
Y1 = dofhandler.coords(node1,2);
X2 = dofhandler.coords(node2,1);
Y2 = dofhandler.coords(node2,2);

u1 = dofhandler.u(ndofs*(node1 - 1)  + 1);
w1 = dofhandler.u(ndofs*(node1 - 1)  + 2);
th1 = dofhandler.u(ndofs*(node1 - 1) + 3);

u2 = dofhandler.u(ndofs*(node2 - 1)  + 1);
w2 = dofhandler.u(ndofs*(node2 - 1)  + 2);
th2 = dofhandler.u(ndofs*(node2 - 1) + 3);

%% Corotational beam element matrix with pretension
if uselinear == 0
    beta0 = atan2(Y2 - Y1, X2 - X1);
    beta  = atan2((Y2+w2) - (Y1+w1), (X2+u2) - (X1+u1));
    c = cos(beta);
    s = sin(beta);
    
    beta1 = th1 + beta0;
    beta2 = th2 + beta0;
    
    th1loc = atan2(cos(beta)*sin(beta1) - sin(beta)*cos(beta1), cos(beta)*cos(beta1) + sin(beta) * sin(beta1));
    th2loc = atan2(cos(beta)*sin(beta2) - sin(beta)*cos(beta2), cos(beta)*cos(beta2) + sin(beta) * sin(beta2));
    
    %th1loc = th1 + beta0 - beta;
    %th2loc = th2 + beta0 - beta;
    
    L0  = sqrt((X2 - X1)^2 + (Y2 - Y1)^2);
    L   = sqrt(((X2 + u2) - (X1 + u1))^2 + ((Y2 + w2) - (Y1 + w1))^2);
    u_l = (L^2 - L0^2)/(L + L0);
    axstrain = (u_l / L0 + prestrain);
    pretension = E * A * prestrain;
    
    N   = E * A * axstrain;
    M1  = 2* E * I /L0 * (2 * th1loc +     th2loc) + pretension*L0/30 * (4 * th1loc - th2loc);
    M2  = 2* E * I /L0 * (    th1loc + 2 * th2loc) + pretension*L0/30 * ( - th1loc  + 4* th2loc);
    
    % Get internal forces in the local corotated coordinates
    flocal = [N; M1; M2];
    
    % Get B matrix
    B = [  -c ,   -s, 0,   c,     s,  0;...
        -s/L,  c/L, 1, s/L,  -c/L,  0;...
        -s/L,  c/L, 0, s/L,  -c/L,  1];
    
    % Get global RHS
    RHSelem = B' * flocal;
    
    % Get consistent tangent matrix
    r = [-c;  -s; 0;   c;  s;  0];
    z = [s;  -c;  0;  -s;  c;  0];
    rg = sqrt(I/A);
    Cbend = E * A/L0 * [1,     0,     0;...
        0, 4*rg*rg, 2*rg*rg;...
        0, 2*rg*rg, 4*rg*rg];
    
    Cpreten = pretension*L0/30 * [ 0, 0, 0;...
        0, 4, -1;...
        0, -1, 4]; % this is weak form based approximation using Hermite interpolation
    
    ktan_trans = B' * (Cbend + Cpreten) * B;
    ktan_geom  = N/L * (z * z') + (M1 + M2)/L/L * (r*z' + z*r');
    
    HESSelem = ktan_trans + ktan_geom; 
else
    %% Linear beam element matrix with pretension
    
    beta0 = atan2(Y2 - Y1, X2 - X1);          % angle of the element for rotation
    L0    = sqrt((X2 - X1)^2 + (Y2 - Y1)^2);  % beam length
    pretension = E * A * prestrain;
    
    dispmat         = [u1, w1, th1, u2, w2, th2]';
    resforcemat_loc = [-pretension, 0, 0, pretension, 0, 0]';
    
    IbyL = I/L0;
    IbyL2 = I/L0^2;
    
    kmatlin_bend = E/L0 * ...
        [A, 0, 0, -A, 0, 0;...
        0, 12*IbyL2, 6*IbyL, 0, -12*IbyL2, 6*IbyL;...
        0, 6*IbyL,   4*I,    0, -6*IbyL,   2*I;...
        -A, 0, 0, A, 0, 0;...
        0, -12*IbyL2, -6*IbyL, 0, 12*IbyL2, -6*IbyL;...
        0, 6*IbyL,   2*I,   0,  -6*IbyL, 4*I];
    
    kmatlin_pretension = pretension/10 * ...
        [0, 0, 0, 0, 0, 0;...
        0, 12/L0,  1,  0,  -12/L0, 1; ...
        0,     1, (4*L0)/3, 0, -1, -L0/3; ...
        0, 0, 0, 0, 0, 0;...
        0, -12/L0, -1,  0, 12/L0, -1;
        0, 1,    -L0/3,     0, -1, (4*L0)/3 ];
    
    kmatlin_loc = kmatlin_bend + kmatlin_pretension;
    
    c0 = cos(beta0);
    s0 = sin(beta0);
    
    rotationmat = [c0, s0, 0, 0, 0, 0;...
        -s0, c0, 0, 0, 0, 0;...
        0, 0, 1, 0, 0, 0;...
        0, 0, 0, c0, s0, 0;...
        0, 0, 0, -s0, c0, 0;...
        0, 0, 0, 0, 0, 1];
    
    HESSelem = rotationmat' * kmatlin_loc * rotationmat;  
    RHSelem  = HESSelem * dispmat + rotationmat' * resforcemat_loc;
end