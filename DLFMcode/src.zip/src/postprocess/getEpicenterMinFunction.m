function Q = getEpicenterMinFunction(epicenter,nodalForces,currpos)

a = [epicenter(1), epicenter(2), 0];
nodalForces(:,3) = 0;
currpos(:,3) = 0;

Q = norm(cross(nodalForces,currpos-a));