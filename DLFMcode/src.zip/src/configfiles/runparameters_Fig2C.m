%% Input data folder
parentfolderformat = strrep(GetFullPath('./testcases/Fig1-CNFMSchematic-Series'),'\','/');

framefolderformat     = 'frame%02d';
nodesdatafileformat   = 'fake_corrected_nodes_%02d.txt';
phaseimagefileformat  = '%02d.jpg';
fluoroimagefileformat = 'fake_%02d_corrected_image.jpg';

%% Preprocessing parameters
% Image resolution
pix2um             = 0.32; % [um\pix]

gridspacing_X      = 25;    % [um]
gridspacing_Y      = 25;    % [um]
spacing_max        = 60;    % [um]

gridspacingX_left   = gridspacing_X;
gridspacingX_right  = gridspacing_X;
gridspacingY_top    = gridspacing_Y;
gridspacingY_bottom = gridspacing_Y;

% Mesh parameters
nNodesfine   = 4;    % nNodes per fiber segment (cell region)
nNodescoarse = 2;    % nNodes per fiber segment (non-cell region)

Lx           = 2000; % Box length (um)
Ly           = 2000; % Box height (um)
hmax         = 1000; % max triangular mesh size
npadlevels   = 2;    % Padded bem mesh levels

%% Inverse analysis prameters
regcoeffmat        = [10,5,2.5,2,1.5,1.0,0.75,0.5,0.25,0.1,0.075,0.05];

framemat           = 570;

Ncases             = length(framemat);
cellIDmat          = ones(Ncases,1);

E_actctrmat        = 1.0 * ones(Ncases,1);
dia_actctrmat      = 2.5 * ones(Ncases,1);

% Frame time (min)
frametime = 5* (0:Ncases-1);

wtNmat      = ones(1,length(framemat));   
wtLmat      = 3* ones(1,length(framemat));  
wtEpmat     = zeros(1,length(framemat));   

E                  = 10^6;  % [kPa]
dia                = 0.25;  % [um]
pretensionF        = 200;   % [nN]

%% Postprocess parameters

% Flags to decide what to plot
plotsigma           = 1;
plotlinetension     = 1;    % 1 to plot line tensions
plotnodalforce      = 0;    % 1 to plot nodal forces
plotdisps           = 1;    % 1 to plot displacement vectors
plotcontractility   = 1;
plotlocalforce      = 0;
plotphaseimage      = 0;
plotcontourmaps     = 0;
plotnanonet         = 0;    % 1 to plot the deformed mesh
plotupdates         = 0;    % 1 to visualize solution while solving

forwardproblem      = 0;    % 1 to plot just the fwd problem solution
comparewithfwdsol   = 0;    % 1 if Fwd solution available for comparison

closefigures        = 0;    % 1 to close all figures after plotting

%% Arrow characteristics
figurewidth           = 20; % [cm]
lenscalebarval        = 50; % [um]
lenscalebar_linewidth = 8;
lenscalebar_color     = 'w';

% Tension arrow scales
sigma_max               = 35;             % [mN/m]
sigmascalefactor        = 25/sigma_max;   % [um / (mN/m)]
sigma_backimage         = 0;              % 0 to use phaseimage, 1 to use fake fluoroscnet image
sigma_arrowcolor        = [0.5 1.0 0.0];
sigma_arrowlinewidth    = 3.5;
sigma_arrowheadsize     = 0.3*sigmascalefactor*sigma_max; % 
sigma_scalebarval       = sigma_max;       % [mN/m] value for the sigma arrow scale bar
sigma_scalebar_textsize = 14;
sigma_showarrowtext     = 0;
sigma_quifactor         = 0.75*sigma_max* sigmascalefactor;

% Displacement arrow scales
disp_max               = 5.0; 
dispscalefactor        = 25/disp_max;    % um/um
dispampfactor          = 1.0;            % to amplify the displacements for def coords
disp_backimage         = 1;              % 0 to use phaseimage, 1 to use fake fluoroscnet image
disp_arrowcolor        = 'y';
disp_arrowlinewidth    = 4;
disp_arrowheadsize     = 0.3*dispscalefactor*disp_max; % 
disp_scalebarval       = disp_max;       % [um] value for the disp arrow scale bar
disp_scalebar_textsize = 14;
disp_showarrowtext     = 0;

% Force arrow scales
f_max              = 250;     % [nN]
fscalefactor       = 25/250;  % [um/nN]

%% Figure size limits
usemaskbasedlimits = 0; % 0 to use manual input

framesize_x = 275; % [um]
framesize_y = 275; % [um]

xmin = 125;
xmax = 400;
ymin = 25;
ymax = 300;

xminmat =  xmin *  ones(Ncases,1);
xmaxmat =  xmax *  ones(Ncases,1);
yminmat =  ymin *  ones(Ncases,1);
ymaxmat =  ymax *  ones(Ncases,1);