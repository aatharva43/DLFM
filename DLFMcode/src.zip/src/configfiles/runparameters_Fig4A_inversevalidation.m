% Inverse problem validation

% Set error introduced in the synthetic dataset
sigma_e           = 0.0; % 0.1, 0.2, 0.5

datafolder = strrep(GetFullPath('./testcases'),'\','/');
fwdsolfolderformat = strcat(datafolder,'/inversesolvervalidation/Cell-%d');
parentfolderformat = sprintf('%s/KnownForceNodes_std%2.3E',fwdsolfolderformat,sigma_e);

framefolderformat     = 'frame%02d';
nodesdatafileformat   = 'fake_corrected_nodes_%02d.txt';
phaseimagefileformat  = '%02d.jpg';
fluoroimagefileformat = 'fake_%02d_corrected_image.jpg';

colorvalmat        = cbrewer('Set1',4);
colorval           = colorvalmat(1,:);

%% Inverse analysis parameters
regcoeffmat        = [10,5,2.5,2,1.5,1.0,0.75,0.5,0.25,0.1,0.075,0.05,0.025,0.01,0.005,0.001];
% regcoeffmat        = 0.1;

plotupdates        = 0; % to visualize solution

cellIDmat          = 2;
framemat           = 3;

Ncases             = length(framemat);

E_actctrmat        = 1.0;
dia_actctrmat      = 2.5;

% Inverse problem parameters
wtNmat      = 1;
wtLmat      = 3;
wtEpmat     = 0;

% Nanofiber parameters
E                  = 10^6;  % [kPa]
dia                = 0.25;  % [um]
pretensionF        = 200;   % [nN]

% Parameters for the surrounding mesh
gridspacing_X      = 25;    % [um]
gridspacing_Y      = 25;    % [um]

%% Postprocess parameters

% Flags to decide what to plot
plotlinetension     = 1;    % 1 to plot line tensions
plotnodalforce      = 0;    % 1 to plot nodal forces
plotdisps           = 1;    % 1 to plot displacement vectors
plotcontractility   = 0;
plotlocalforce      = 0;
plotphaseimage      = 1;
plotcontourmaps     = 0;
plotnanonet         = 1;    % 1 to plot the deformed mesh

forwardproblem      = 0;    % 1 to plot just the fwd problem solution
comparewithfwdsol   = 0;    % 1 if Fwd solution available for comparison

closefigures        = 0;    % 1 to close all figures after plotting

%% Arrow characteristics
figurewidth           = 20; % [cm]
lenscalebarval        = 50; % [um]
lenscalebar_linewidth = 8;
lenscalebar_color     = 'k';

% Tension arrow scales
plotsigma              = 1;
sigma_max               = 25;             % [mN/m]
sigmascalefactor        = 25/sigma_max;   % [um / (mN/m)]
sigma_backimage         = 0;              % 0 to use phaseimage, 1 to use fake fluoroscnet image
sigma_arrowcolor        = [50 205 50]/255;
sigma_arrowlinewidth    = 6;
sigma_arrowheadsize     = 0.25*sigmascalefactor*sigma_max; % 
sigma_scalebarval       = sigma_max;       % [mN/m] value for the sigma arrow scale bar
sigma_scalebar_textsize = 14;
sigma_showarrowtext     = 0;
sigma_quifactor         = 0.75*sigma_max* sigmascalefactor;
sigma_fwd_arrowcolor    = 'r';

% Displacement arrow scales
disp_max               = 3.0; 
dispscalefactor        = 25/disp_max;    % um/um
dispampfactor          = 1.0;            % to amplify the displacements for def coords
disp_backimage         = 1;              % 0 to use phaseimage, 1 to use fake fluoroscnet image
disp_arrowcolor        = [218,165,32]/255;
disp_arrowlinewidth    = 6;
disp_arrowheadsize     = 0.3*dispscalefactor*disp_max; % 
disp_scalebarval       = disp_max;       % [um] value for the disp arrow scale bar
disp_scalebar_textsize = 14;
disp_showarrowtext     = 0;

% Force arrow scales
force_max               = 1250;       % [nN]
forcescalefactor        = 25/force_max;  % [um/nN]
force_arrowcolor        = sigma_arrowcolor;
force_arrowlinewidth    = sigma_arrowlinewidth;
force_arrowheadsize     = 0.25*forcescalefactor*force_max; % 
force_scalebarval       = force_max;       % [mN/m] value for the force arrow scale bar
force_scalebar_textsize = 14;
force_showarrowtext     = 0;
force_quifactor         = 0.75*force_max* forcescalefactor;

%% Figure size limits
usemaskbasedlimits = 1;
xminmat = 75;
xmaxmat = 275;
yminmat = 50;
ymaxmat = 250;

framesize_x = 200;
framesize_y = 200;

%% Other related info

% Saving compiled figures for validation
% saveCommonFiguresFolder = sprintf('%s/Figures_validation/',fwdsolfoldername);
% if ~isfolder(saveCommonFiguresFolder)
%     mkdir(saveCommonFiguresFolder)
% end
% 
% Cerrfilename = sprintf('%s/Cell1_withoutnoise_forcerecovery',saveCommonFiguresFolder);
% print(fhCerr, [Cerrfilename,'.png'],'-dpng','-r300');
% print(fhCerr, [Cerrfilename,'.eps'],'-depsc');