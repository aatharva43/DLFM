function [xelems_intp,yelems_intp] = getHermiteInterpolatedCoords(beammesh,Npts)
% Hermite interpolation to generate smooth lines for plotting the beam mesh
% Npts, number of additional points to plot the mesh

if nargin < 2
    Npts = 2;
end

Nelems = beammesh.Nelems * (Npts + 1); % New number of elements
xelems_intp = zeros(Nelems,2);
yelems_intp = zeros(Nelems,2);

ximat = linspace(-1,1,Npts+2);

for oldelemID = 1:beammesh.Nelems
    node1 = beammesh.connec(oldelemID,1);
    node2 = beammesh.connec(oldelemID,2);
    
    X1 = beammesh.coords(node1,1);
    Y1 = beammesh.coords(node1,2);
    X2 = beammesh.coords(node2,1);
    Y2 = beammesh.coords(node2,2);
    
    u1 = beammesh.u(beammesh.dofs*(node1 - 1)  + 1);
    w1 = beammesh.u(beammesh.dofs*(node1 - 1)  + 2);
    th1 = beammesh.u(beammesh.dofs*(node1 - 1) + 3);
    
    u2 = beammesh.u(beammesh.dofs*(node2 - 1)  + 1);
    w2 = beammesh.u(beammesh.dofs*(node2 - 1)  + 2);
    th2 = beammesh.u(beammesh.dofs*(node2 - 1) + 3);
    
    beta0 = atan2(Y2 - Y1, X2 - X1);
    beta  = atan2((Y2+w2) - (Y1+w1), (X2+u2) - (X1+u1));
    
    beta1 = th1 + beta0;
    beta2 = th2 + beta0;
    
    th1loc = atan2(cos(beta)*sin(beta1) - sin(beta)*cos(beta1), cos(beta)*cos(beta1) + sin(beta) * sin(beta1));
    th2loc = atan2(cos(beta)*sin(beta2) - sin(beta)*cos(beta2), cos(beta)*cos(beta2) + sin(beta) * sin(beta2));
    
    %th1loc = th1 + beta0 - beta;
    %th2loc = th2 + beta0 - beta;
    
    Le   = sqrt(((X2 + u2) - (X1 + u1))^2 + ((Y2 + w2) - (Y1 + w1))^2);
    
    N1   = Le/8 * (1 - ximat).^2.*(ximat + 1);
    N2   = Le/8 * (1 + ximat).^2.*(ximat - 1);
    wmat = N1*th1loc + N2*th2loc;
    
    % deformed positions
    xmat = (1 - ximat)/2 * (X1 + u1) + (1 + ximat)/2 * (X2 + u2) - wmat * sin(beta);
    ymat = (1 - ximat)/2 * (Y1 + w1) + (1 + ximat)/2 * (Y2 + w2) + wmat * cos(beta);
    
    xelems_intp((oldelemID-1)*(Npts + 1)+1:oldelemID*(Npts + 1),1) = xmat(1:end-1); 
    xelems_intp((oldelemID-1)*(Npts + 1)+1:oldelemID*(Npts + 1),2) = xmat(2:end);
    yelems_intp((oldelemID-1)*(Npts + 1)+1:oldelemID*(Npts + 1),1) = ymat(1:end-1); 
    yelems_intp((oldelemID-1)*(Npts + 1)+1:oldelemID*(Npts + 1),2) = ymat(2:end);
end
